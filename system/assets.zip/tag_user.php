<?php
	include("database.php");	
	
	$encoder_id = $_GET["e"];
	$user_id = $_GET["id"];
	$action = $_GET["action"];
	
	if (in_array($action, [1, 2, 3])){
		$sql = " status = " . $action;
	}
	else {
		if ($action == 4)
			$t_action = 3; # SET AS ADMIN
		else
			$t_action = 1; # SET AS ENCODER
		$sql = " privilege = " . $t_action;
	}
	
	
	$stmt = $conn->prepare("UPDATE users set " . $sql . ", change_status_date = NOW() where id = ?");
	$stmt->bind_param("s", $user_id);
	$stmt->execute();
	$stmt->close();
	
	$log_string = "Tagged user as " . $action;
	
	include("insert_log.php");
	
	session_start();
	$_SESSION['message'] = "Tag successful!";
	$_SESSION['msg_type'] = "success";
	
	die(header("Location: users.php?r=reg_success")); 
	
?>
