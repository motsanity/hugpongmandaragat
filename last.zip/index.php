<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v4.12.0, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.0, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/timo-122x122.png" type="image/x-icon">
  <meta name="description" content="">
  
  <title>HM - Home</title>
  <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/facebook-plugin/style.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
  <section class="menu cid-rSgAUllw2H" once="menu" id="menu1-1">

    
    

    <nav class="navbar navbar-dropdown navbar-fixed-top navbar-expand-lg">
        <div class="navbar-brand">
            <span class="navbar-logo">
                <a href="index.php">
                    <img src="assets/images/timo-122x122.png" alt="Mobirise" title="" style="height: 3.8rem;">
                </a>
            </span>
            
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown nav-right" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-primary display-4" href="index.php">
                        Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-primary display-4" href="membership.php">Membership</a>
                </li><li class="nav-item"><a class="nav-link link text-primary display-4" href="form.xlsx">Download Application Form</a></li><li class="nav-item"><a class="nav-link link text-primary display-4" href="socials.php">Socials</a></li><li class="nav-item"><a class="nav-link link text-primary display-4" href="faq.php">FAQs</a></li>
                <li class="nav-item">
                    <a class="nav-link link text-primary display-4" href="contact.php">Contact Us</a>
                </li></ul>
            <div class="icons-menu">
              <div class="soc-item">
                <a href="https://twitter.com/HugpongI" target="_blank">
                  <span class="mbr-iconfont socicon-twitter socicon" style="color: rgb(82, 229, 229); fill: rgb(82, 229, 229);"></span>
                </a>
              </div>
              <div class="soc-item">
                <a href="https://www.facebook.com/DamayandeMarinero/?__tn__=%2Cd%2CP-R&eid=ARAZ1p5VnYPcJbW2mVSbtv6dXzxaow8wtN7WVZgCF7S-TrazuU6sOE5E1d4L9CvdJD__wClWLi1h9AmD" target="_blank">
                  <span class="mbr-iconfont socicon-facebook socicon" style="color: rgb(24, 142, 244); fill: rgb(24, 142, 244);"></span>
                </a>
              </div>
              
              
              
              
            </div>
            
      </div>
    </nav>
</section>

<section class="header4 cid-rSgWIyJT4y mbr-fullscreen mbr-parallax-background" id="header4-a">

    

    <div class="mbr-overlay" style="opacity: 0.8; background-color: rgb(59, 124, 183);">
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="mbr-white col-md-12 col-lg-6">
                <div class="typed-text pb-3 align-left display-1">
                    <span class="mbr-section-subtitle mbr-fonts-style display-1">
                          <br><br><br>HUGPONG MANDARAGAT INC. is a</span>
                    <span>
                      <span class="animated-element mbr-bold" data-speed="50" data-word1="non-stock.." data-word2="non-profit.." data-word3="Unique" data-word4="Lorem" data-word5="Ipsum" data-words="2">
                      </span>
                    </span>
                </div>
                
                
            </div>
            <div class="col-lg-6">
                <div class="mbr-figure">
                    <img src="assets/images/timo-4-1080x1081.png" alt="Mobirise" title="">
                </div>
            </div>
        </div>
    </div>
    
</section>

<section class="features16 cid-rSgD2SOlid mbr-parallax-background" id="features16-3">
    

    <div class="mbr-overlay" style="opacity: 0.8;">
    </div>

    <div class="container">
        <div class="row main-row">
            <div class="text-block mb-4 col-lg-6">
                <h2 class="mb-4 mbr-fonts-style mbr-section-title display-2"><br>About Us</h2>
                <h3 class="mbr-fonts-style mbr-text section-text align-left  display-7"><br>HUGPONG MANDARAGAT INC., is a non-stock and non-profit Organization which was created based on a sodality of seafarers led by Capt. Rafael F. Dorona Jr. and the entire Crew of LPG/ C TAMARA. HUGPONG MANDARAGAT INC. was conceptualized out of compassion to our fellow seafarers in cases involving death or permanent disability to any of its registered member or beneficiary.</h3>
                <div class="mbr-text counter-container col-12  mbr-fonts-style display-7">
                    <div><br></div>
                </div>
                
            </div>
     
            <div class="mbr-figure col-lg-5">
            	<div class="mbr-figure__img">
                    <img src="assets/images/ground-group-growth-hands-461049-950x769.jpg" alt="Mobirise" title="">
                </div>
            	
            </div>

        </div>
    </div>
</section>

<section class="features10 cid-rSgE0mOEB5 mbr-parallax-background" id="features10-4">

    

    <div class="mbr-overlay" style="opacity: 0.7; background-color: rgb(0, 0, 0);">
    </div>
    <div class="container">
    	<h2 class="mbr-fonts-style mb-3 mbr-section-title align-center display-1">Our Goal</h2>
        <h3 class="mbr-section-subtitle mbr-text mbr-fonts-style mb-4 mbr-light align-center display-5"><em>the purposes for which it was organized are as follows:</em></h3>


        <div class="rows-wrapper">
            <div class="row main align-items-center top-radius">
                <div class="col-md-4 text-element">
                    <div class="text-content">
                        <div class="card-img pb-3 align-center">
                            <span class="mbr-iconfont mbri-flag"></span>
                        </div>
                        <h2 class="mbr-title  mbr-fonts-style align-center display-5">1. Social Awareness</h2>
                        <p class="mbr-text card-text mbr-light mbr-fonts-style align-center display-7">To promote social awareness and responsibility among the members and beneficiaries of HUGPONG MANDARAGAT INC.</p>
                        
                    </div>
                </div>
                <div class="col-md-4 image-element align-self-stretch">
                    <div class="img-wrap">
                        <img src="assets/images/computer-desk-laptop-stethoscope-48604-740x472.jpg" alt="" title="">
                    </div>
                </div>
                <div class="col-md-4 text-element">
                    <div class="text-content">
                        <div class="card-img pb-3 align-center">
                            <span class="mbr-iconfont mbri-user"></span>
                        </div>
                        <h2 class="mbr-title  mbr-fonts-style align-center display-5">
                            2. Financial Assitance</h2>
                        <p class="mbr-text card-text mbr-light mbr-fonts-style align-center display-7">To provide financial assistance to the beneficiaries in case of death of any member.</p>
                        
                    </div>
                </div>
            </div>
            <div class="row main-reverse align-items-center">
                <div class="col-md-4 image-element align-self-stretch">
                    <div class="img-wrap">
                        <img src="assets/images/black-calculator-near-ballpoint-pen-on-white-printed-paper-53621-740x436.jpg" alt="" title="">
                    </div>
                </div>
                <div class="col-md-4 text-element">
                    <div class="text-content">
                        <div class="card-img pb-3 align-center">
                            <span class="mbr-iconfont mbri-users"></span>
                        </div>
                        <h2 class="mbr-title  mbr-fonts-style align-center display-5">3. Financial Assistance for Family</h2>
                        <p class="mbr-text card-text mbr-light mbr-fonts-style align-center display-7">To provide financial assistance to any member in case of death of any direct family member.</p>
                        
                    </div>
                </div>
                <div class="col-md-4 image-element align-self-stretch">
                    <div class="img-wrap">
                        <img src="assets/images/adventure-backlit-dawn-dusk-207896-740x393.jpg" alt="" title="">
                    </div>
                </div>
            </div>
            <div class="row main align-items-center">
                
                <div class="col-md-4 text-element">
                    <div class="text-content">
                        <div class="card-img pb-3 align-center">
                            <span class="mbr-iconfont mbri-like"></span>
                        </div>
                        <h2 class="mbr-title  mbr-fonts-style align-center display-5">
                            Financial Assistance for Incapacitated person</h2>
                        <p class="mbr-text card-text mbr-light mbr-fonts-style align-center display-7">To provide financial assistance to members who are declared incapacitated to work.</p>
                        
                    </div>
                </div>
                <div class="col-md-4 image-element align-self-stretch">
                    <div class="img-wrap">
                        <img src="assets/images/achievement-confident-free-freedom-6945-740x555.jpg" alt="" title="">
                    </div>
                </div>
                <div class="col-md-4 text-element">
                    <div class="text-content">
                        <div class="card-img pb-3 align-center">
                            <span class="mbr-iconfont mbri-clock"></span>
                        </div>
                        <h2 class="mbr-title  mbr-fonts-style align-center display-5">
                            Emergency</h2>
                        <p class="mbr-text card-text mbr-light mbr-fonts-style align-center display-7">To provide emergency funds to all members and direct family members.</p>
                        
                    </div>
                </div>
            </div>
            <div class="row main-reverse align-items-center bottom-radius">
                <div class="col-md-4 image-element align-self-stretch">
                    <div class="img-wrap">
                        <img src="assets/images/photo-of-woman-holding-a-green-paper-736842-740x494.jpg" alt="" title="">
                    </div>
                </div>
                <div class="col-md-4 text-element">
                    <div class="text-content">
                        <div class="card-img pb-3 align-center">
                            <span class="mbr-iconfont mbri-briefcase"></span>
                        </div>
                        <h2 class="mbr-title  mbr-fonts-style align-center display-5">
                            Unemployed benefits</h2>
                        <p class="mbr-text card-text mbr-light mbr-fonts-style align-center display-7">
                            To provide assistance to members, including their direct family member while unemployed or while on vacation in the Philippines.</p>
                        
                    </div>
                </div>
                <div class="col-md-4 image-element align-self-stretch">
                    <div class="img-wrap">
                        <img src="assets/images/photo-of-pwd-sign-3095954-740x1110.jpeg" alt="" title="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="tabs1 cid-rSHoF9CTDY" id="tabs1-2j">

    

    
    <div class="container">
        <h2 class="mbr-section-title align-center mbr-fonts-style pb-3 display-2">
            Mission and Vision</h2>
         
        <div class="media-container-row">
            <div class="col-12 col-md-10">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item"><a class="nav-link mbr-fonts-style active show display-7" role="tab" data-toggle="tab" href="#tabs1-2j_tab0" aria-selected="true">
                            Mission</a></li>
                    <li class="nav-item"><a class="nav-link mbr-fonts-style active show display-7" role="tab" data-toggle="tab" href="#tabs1-2j_tab1" aria-selected="true">Vision</a></li>
                    <li class="nav-item"><a class="nav-link mbr-fonts-style active show display-7" role="tab" data-toggle="tab" href="#tabs1-2j_tab2" aria-selected="true">
                            Value Statement</a></li>
                    
                </ul>
                <div class="tab-content">
                    <div id="tab1" class="tab-pane in active" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-6">
                            	<h4 class="display-2 align-left title-content pb-2 mbr-fonts-style"> 
                                Mission</h4>
                                <p class="mbr-text mbr-fonts-style align-left display-7">HUGPONG MANDARAGAT IS
COMMITTED TO PROVIDING ALL
SEAFARERS THE HIGHEST QUALITY
OF SERVICE WITH THE GOAL THAT
TRANSCENDS THEIR EXPECTATIONS THROUGH THE PRINCIPLES OF SERVICE, INTEGRITY AND
PROFESSIONALISM.<br><br>OUR PLEDGE TO OUR MEMBERS IS TO PROVIDE FINANCIAL SUPPORT ESPECIALLY IN TIMES OF DESPAIR, AND WE WILL REMAIN FLEXIBLE AND INNOVATIVE IN ORDER TO CATER THE CHANGING NEEDS OF ALL SEAFARERS.</p>
                                
                            </div>
                            <div class="col-lg-6">
                                <div class="card-img"><img src="assets/images/timo-866x867.png" alt="" title=""></div>
                            </div>
                        </div>
                    </div>
                    <div id="tab2" class="tab-pane" role="tabpanel">
                        <div class="row">
                           <div class="col-lg-6">
                           		<h4 class="display-2 align-left title-content pb-2 mbr-fonts-style"> 
		     			        Vision</h4>
                                <p class="mbr-text mbr-fonts-style align-left display-7">
                                    OUR SERVICE IS COMMITTED TO BECOMING A LIFE CHANGER AMONG SEAFARERS BY BEING INNOVATIVE, FINANCIALLY STRONG, PROVIDING THE RIGHT SUPPORT AND EFFICIENT SERVICE. WE REMAIN DEDICATED TO A HIGH LEVEL OF EXCELLENCE BY ALWAYS STRIVING TO CONTINUOUSLY IMPROVE IN ORDER TO ACHIEVE A GOAL OF CREATING LONG TERM RELATIONSHIPS THAT WILL LAST FOR GENERATIONS.
                                </p>
                                 
                            </div>
                              <div class="col-lg-6 pb-3">
                                <div class="card-img"><img src="assets/images/timo-866x867.png" alt="" title=""></div>
                            </div>
                        </div>
                    </div>
                    <div id="tab3" class="tab-pane" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-6">
                            	<h4 class="display-2 align-left title-content pb-2 mbr-fonts-style"> 
		     			        Value Statement</h4>
                                <p class="mbr-text mbr-fonts-style align-left display-7">WE MAYBE DELAYED TO OUR
DESTINATION DUE TO STRONG
WINDS AND HEAD ON CURRENTS,
BUT WE WILL ALWAYS HEAD TO
THE PORTS AND STEER STRAIGHT
TOWARDS THE HARBOUR
WE ARE DEPENDABLE, STEADY AND
CALM INSIDE THE STORM
WE CHALLENGE, WE ADAPT, WE FIGHT, WE BEND, BUT WE WILL NEVER BREAK.<br></p>
                                
                            </div>
                              <div class="col-lg-6">
                                <div class="card-img"><img src="assets/images/timo-866x867.png" alt="" title=""></div>
                            </div>
                        </div>
                    </div>
                    <div id="tab4" class="tab-pane" role="tabpanel">
                        <div class="row">
                            <div class="col-lg-6">
                            	<h4 class="display-2 align-left title-content pb-2 mbr-fonts-style"> 
		     			        Lorem ipsum dolor sit amet
		     			        </h4>
                                <p class="mbr-text mbr-fonts-style align-left display-7">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem laudantium in adipisci ipsa optio quas id excepturi non, eos cupiditate, necessitatibus sapiente illo error. Vero adipisci quidem aut itaque labore.
                                </p>
                                
                            </div>
                            <div class="col-lg-6">
                                <div class="card-img"><img src="assets/images/07.jpg" alt=""></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="teams1 cid-rSqGiPFmui" id="teams1-1v">
    
    

    
    <div class="container"><hr>
        <h2 class="mbr-section-title  pb-3 mbr-fonts-style align-center  display-2">Our Team</h2>
        <h3 class="mbr-section-subtitle pb-4 mbr-fonts-style align-center mbr-light display-7"><em>
            Founders of The Organization</em></h3>
        <div class="media-container-row">

            <div class="card p-3 col-12 col-md-6">
                <div class="card-img ">
                    <img class="img-icon" src="assets/images/88030956-489753175033247-212125423977365504-n-1-366x365.jpg" alt="Mobirise" title="">
                </div>
                <div class="card-box align-center">
                    <h4 class="card-title mbr-fonts-style mbr-semibold display-5">Capt. Rafael F.
<div>Dorona Jr.</div></h4>
                    <h5 class="user-desc mbr-fonts-style display-4"><em><strong>
                        President
                    </strong></em></h5>
                    <p class="mbr-text mbr-fonts-style display-7">B.S Marine Transportation.
<br>&nbsp;Misamis Institute of Technology, Ozamiz City.
<br>Master Mariner 2014 up to present.<br><br></p>
                    <div class="social-links">
                        <a href="https://www.facebook.com/profile.php?id=100009340497544" target="_blank">
                            <span class="px-2 mbr-iconfont mbr-iconfont-social fa-facebook-f fa"></span>
                        </a>
                        
                        
                        
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 align-center">
                <div class="card-img ">
                    <img class="img-icon" src="assets/images/84180470-233598954343124-4626328725875589120-n-367x368.jpg" alt="Mobirise" title="">
                </div>
                <div class="card-box">
                    <h4 class="card-title mbr-fonts-style mbr-semibold display-5">Chief Engineer Glenn Esber</h4>
                    <h5 class="user-desc mbr-fonts-style display-4"><em><strong>Vice President</strong></em></h5>
                    <p class="mbr-text mbr-fonts-style display-7">B.S. Marine Engineering <br>&nbsp;PMI Colleges, Quezon City
<br>&nbsp;Foscon Shipmanagement<br>inc.<br><br></p>
                    <div class="social-links">
                        <a href="https://www.facebook.com/bleiss.efarm.7" target="_blank">
                            <span class="px-2 mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                        </a>
                        
                        
                        
                    </div>
                </div>
            </div>

            

            

        </div>
    </div>
</section>

<section class="teams1 cid-rSN1i3Xdsv" id="teams1-2p">
    
    

    
    <div class="container">
        <h2 class="mbr-section-title  pb-3 mbr-fonts-style align-center  display-2">
            Board of Trustees</h2>
        
        <div class="media-container-row">

            <div class="card p-3 col-12 col-md-6 col-lg-4">
                <div class="card-img ">
                    <img class="img-icon" src="assets/images/87024228-623340938456281-1548570559019745280-n-367x368.jpg" alt="Mobirise" title="">
                </div>
                <div class="card-box align-center">
                    <h4 class="card-title mbr-fonts-style mbr-semibold display-5">Chief Officer Felix Garciano</h4>
                    <h5 class="user-desc mbr-fonts-style display-4"><strong><em>
                        Trustee
                    </em></strong></h5>
                    <p class="mbr-text mbr-fonts-style display-7">B.S Marine Transportation 
<br>MATS College of technology License master mariner, FOSCON Shipmanagement inc.</p>
                    <div class="social-links">
                        <a href="https://www.facebook.com/flex.garciano?epa=SEARCH_BOX" target="_blank">
                            <span class="px-2 mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                        </a>
                        
                        
                        
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 align-center col-lg-4">
                <div class="card-img ">
                    <img class="img-icon" src="assets/images/87660727-753452451729638-2538677373922967552-n-400x398.jpg" alt="Mobirise" title="">
                </div>
                <div class="card-box">
                    <h4 class="card-title mbr-fonts-style mbr-semibold display-5">Chief Engineer Victor Miranda</h4>
                    <h5 class="user-desc mbr-fonts-style display-4"><strong><em>
                        Trustee
                    </em></strong></h5>
                    <p class="mbr-text mbr-fonts-style display-7">B.S Marine Engineering 
<br>FEATI University 
<br>FOSCON Shipmanagement inc.&nbsp;<br><br></p>
                    <div class="social-links">
                        <a href="https://www.facebook.com/victor.miranda.56232938" target="_blank">
                            <span class="px-2 mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                        </a>
                        
                        
                        
                    </div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 align-center col-lg-4">
                <div class="card-img ">
                    <img class="img-icon" src="assets/images/87454864-237244674116763-9170163383536713728-n-2-400x368.jpeg" alt="Mobirise" title="">
                </div>
                <div class="card-box">
                    <h4 class="card-title mbr-fonts-style mbr-semibold display-5">Ferdimark G. Costelo</h4>
                    <h5 class="user-desc mbr-fonts-style display-4"><strong><em>Trustee</em></strong></h5>
                    <p class="mbr-text mbr-fonts-style display-7">
                        BS Marine Engineering<br>PMMS Las Pinas<br>Passed OIC-EW 2019<br>Foscon Shipmanagement Inc.<br>
                    </p>
                    <div class="social-links">
                        <a href="https://www.facebook.com/ferdimark.costelo" target="_blank">
                            <span class="px-2 mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                        </a>
                        
                        
                        
                    </div>
                </div>
            </div>

            

        </div>
    </div>
</section>

<section class="mbr-section info3 cid-rSkSxoR5Pv" id="info3-1q">

    

    
    <div class="container">
        <div class="row justify-content-center content-row">
            <div class="media-container-column title col-12 col-lg-7 col-md-6">
                <h2 class="align-left mbr-bold mbr-fonts-style pb-3 display-2">
                    Start today. Discover a new approach.</h2>
                <h3 class="mbr-section-subtitle align-left mbr-light mbr-fonts-style display-5"><strong>Be part of our organization.</strong></h3>
            </div>
            <div class="media-container-column col-12 col-lg-3 col-md-4">
                <div class="mbr-section-btn align-right py-4"><a class="btn btn-success btn-md display-4" href="requirements.php">Click here</a></div>
            </div>
        </div>
    </div>
</section>

<section class="cid-rSgMEWxlxT" id="footer2-9">

    

    

    <div class="container">
        <div class="media-container-row content text-white">
               <div class="col-md-6  mbr-fonts-style display-7 col-lg-3">
                <h5 class="pb-3 mbr-black title-card">
                    Address
                </h5>
                <p class="mbr-text p-title">Palacio Grande bldg, Gen. Luna St. cor. Anda St. Intramuros, Manila, Philippines</p>
            </div>
            <div class="col-md-6  mbr-fonts-style display-7 col-lg-3">
                <h5 class="pb-3 mbr-black title-card">
                    Phone
                </h5>
                <p class="mbr-text p-title">
                  Office : +639281799389<br><br></p>
            </div>
            <div class="col-md-6 mbr-fonts-style display-7 col-lg-3">
                <h5 class="pb-3 mbr-black title-card">
                    Email
                </h5>
                <p class="mbr-text p-title">inquiry@<br>hugpongmandaragat.com</p>
            </div>
            <div class="col-md-6 mbr-fonts-style display-7 col-lg-3">
                <h5 class="pb-3 mbr-black title-card">
                    Social
                </h5>
           <div class="social-media pb-3 align-left">
                        <ul>
                            <li>
                                <a class="icon-transition" href="https://www.facebook.com/DamayandeMarinero/" target="_blank">
                                    <span class="mbr-iconfont socicon-facebook socicon"></span>
                                </a>
                            </li>
                            <li>
                                <a class="icon-transition" href="https://twitter.com/HugpongI" target="_blank">
                                    <span class="mbr-iconfont socicon-twitter socicon"></span>
                                </a>
                            </li>
                            
                            
                            
                            
                        </ul>
                    </div>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-6 copyright">
                	<a href="index.php"><img src="assets/images/timo-96x96.png" alt="" title="" style="width: 3rem;"></a>
                    <p class="mbr-text mbr-fonts-style display-7">
                        All Rights Reserved by HUGPONG MANDARAGAT INC. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>
                </div>
                <div class="col-md-6 menu-list">
					<div class="footer-menu">
						
						
						
						
						
					<span class="footer-menu__item"></span><span class="footer-menu__item"></span><span class="footer-menu__item"></span><span class="footer-menu__item"></span><span class="footer-menu__item"></span></div>
                </div>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5"></script>
  <script src="https://apis.google.com/js/plusone.js"></script>
  <script src="assets/facebook-plugin/facebook-script.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/typed/typed.min.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/mbr-tabs/mbr-tabs.js"></script>
  <script src="assets/touch-swipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  
  
</body>
</html>